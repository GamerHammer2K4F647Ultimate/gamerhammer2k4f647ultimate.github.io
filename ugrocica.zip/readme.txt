Original backgrounds:https://files.enderman.ch/wallpapers/
Jumping cat (ugrocica): https://discord.com/channels/954728808173424691/954729703397294130/1211242225829412914
https://media.discordapp.net/attachments/954729703397294130/1211242224042508308/New_-_Desktop_Background_Dark.png
F-22A image: https://www.jetphotos.com/photo/11165288

for the .pdn files contact me on discord

by hammer (discord: hmar_)